import sys
from pybin.cli import pybin
sys.exit(pybin())
